﻿namespace AwesomeGICBank.Models
{
    public class Transaction
    {
        public string TransactionId { get; set; } // Unique identifier for each transaction
        public string AccountNumber { get; set; } // Foreign key reference to the account
        public DateTime Date { get; set; } // Date of the transaction
        public string Type { get; set; } // Type of transaction (D for Deposit, W for Withdrawal)
        public decimal Amount { get; set; } // Amount of the transaction

        // Navigation property
        public virtual Account Account { get; set; } // Navigation property to the Account
    }
}
