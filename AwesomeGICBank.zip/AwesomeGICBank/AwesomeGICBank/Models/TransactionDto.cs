﻿namespace AwesomeGICBank.Models
{
    public class TransactionDto
    {
        public string AccountNumber { get; set; }  // Property for the account number
        public string Date { get; set; }            // Transaction date in YYYYMMdd format
        public string Type { get; set; }            // Transaction type: D for deposit, W for withdrawal
        public decimal Amount { get; set; }         // Amount of the transaction
    }
}
