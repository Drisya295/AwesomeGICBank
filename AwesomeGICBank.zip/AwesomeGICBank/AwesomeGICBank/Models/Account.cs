﻿using System.Collections.Generic;

namespace AwesomeGICBank.Models
{
    public class Account
    {
        public int Id { get; set; } // If using string, change to string
        public string AccountNumber { get; set; }
        public decimal Balance { get; set; }

        // Navigation property
        public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
    }
}
