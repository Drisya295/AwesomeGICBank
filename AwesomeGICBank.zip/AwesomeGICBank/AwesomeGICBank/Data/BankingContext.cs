﻿using Microsoft.EntityFrameworkCore;
using AwesomeGICBank.Models;

namespace AwesomeGICBank.Data
{
    public class BankingContext : DbContext
    {
        public BankingContext(DbContextOptions<BankingContext> options) : base(options)
        {
        }

        public DbSet<Account> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<InterestRule> InterestRules { get; set; }

        // Customize model creation (like relationships or constraints)
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Account has many Transactions
            modelBuilder.Entity<Account>()
                .HasMany(a => a.Transactions)
                .WithOne(t => t.Account) // Each Transaction belongs to one Account
                .HasForeignKey(t => t.AccountNumber) // Foreign key in Transaction
                .OnDelete(DeleteBehavior.Cascade); // Optional: specify behavior on delete

            // InterestRule: You might want to have a unique constraint for the same date
            modelBuilder.Entity<InterestRule>()
                .HasIndex(ir => new { ir.Date, ir.RuleId })
                .IsUnique();

            // Additional configurations can go here

            // For example: 
            // Setting precision for decimal properties
            modelBuilder.Entity<Transaction>()
                .Property(t => t.Amount)
                .HasColumnType("decimal(18, 2)"); // Adjust precision and scale as necessary
        }
    }
}
