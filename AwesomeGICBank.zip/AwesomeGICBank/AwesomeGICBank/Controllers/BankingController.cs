﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AwesomeGICBank.Data;
using AwesomeGICBank.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AwesomeGICBank.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BankingController : ControllerBase
    {
        private readonly BankingContext _context;

        public BankingController(BankingContext context)
        {
            _context = context;
        }

        [HttpPost("add-transaction")]
        public async Task<IActionResult> AddTransaction([FromBody] TransactionDto transactionDto)
        {
            if (!IsValidTransaction(transactionDto))
            {
                return BadRequest("Invalid transaction details.");
            }

            var account = await _context.Accounts
                .FirstOrDefaultAsync(a => a.AccountNumber == transactionDto.AccountNumber);

            if (account == null)
            {
                // Create the account if it does not exist
                account = new Account
                {
                    AccountNumber = transactionDto.AccountNumber,
                    Balance = 0 // Initial balance
                };
                await _context.Accounts.AddAsync(account);
            }

            // Validate and update balance
            if (transactionDto.Type.Equals("W", StringComparison.OrdinalIgnoreCase) && account.Balance < transactionDto.Amount)
            {
                return BadRequest("Insufficient funds for withdrawal.");
            }

            // Create and add the transaction
            var transaction = new Transaction
            {
                TransactionId = GenerateTransactionId(transactionDto.Date),
                AccountNumber = account.AccountNumber,
                Date = DateTime.ParseExact(transactionDto.Date, "yyyyMMdd", null), // Parse string to DateTime
                Type = transactionDto.Type,
                Amount = transactionDto.Amount
            };

            if (transactionDto.Type.Equals("D", StringComparison.OrdinalIgnoreCase))
            {
                account.Balance += transactionDto.Amount; // Deposit
            }
            else
            {
                account.Balance -= transactionDto.Amount; // Withdrawal
            }

            await _context.Transactions.AddAsync(transaction);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Transaction added successfully.", TransactionId = transaction.TransactionId });
        }

        [HttpGet("print-statement/{accountNumber}/{yearMonth}")]
        public async Task<IActionResult> PrintStatement(string accountNumber, string yearMonth)
        {
            // Get the year and month from the input
            var year = yearMonth.Substring(0, 4);
            var month = yearMonth.Substring(4, 2);

            // Parse dates
            DateTime startDate = new DateTime(int.Parse(year), int.Parse(month), 1);
            DateTime endDate = startDate.AddMonths(1).AddDays(-1);

            // Fetch the account
            var account = await _context.Accounts
                .Include(a => a.Transactions)
                .FirstOrDefaultAsync(a => a.AccountNumber == accountNumber);

            if (account == null)
            {
                return NotFound("Account not found.");
            }

            // Filter transactions for the specified month
            var transactions = account.Transactions
                .Where(t => t.Date >= startDate && t.Date <= endDate)
                .OrderBy(t => t.Date)
                .ToList();

            // Calculate balance and interest
            decimal balance = account.Balance; // This should reflect the actual end-of-month balance

            // Print the account statement
            var statement = new
            {
                AccountId = accountNumber,
                Transactions = transactions.Select(t => new
                {
                    t.Date,
                    t.TransactionId,
                    t.Type,
                    t.Amount,
                    Balance = balance // Placeholder for actual balance after transaction
                }).ToList()
            };

            return Ok(statement);
        }

        private bool IsValidTransaction(TransactionDto transactionDto)
        {
            // Validate the transaction details here
            if (string.IsNullOrEmpty(transactionDto.AccountNumber) ||
                string.IsNullOrEmpty(transactionDto.Date) ||
                string.IsNullOrEmpty(transactionDto.Type) ||
                transactionDto.Amount <= 0)
            {
                return false;
            }

            // Ensure the transaction type is valid
            if (!transactionDto.Type.Equals("D", StringComparison.OrdinalIgnoreCase) &&
                !transactionDto.Type.Equals("W", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            // Further validation rules can be added here

            return true;
        }

        private string GenerateTransactionId(string date)
        {
            // Generate transaction ID in the format YYYYMMdd-xx
            var datePart = date; // YYYYMMdd
            var transactionCount = _context.Transactions.Count(t => t.Date.ToString("yyyyMMdd") == datePart);
            var transactionNumber = (transactionCount + 1).ToString("D2"); // Ensures two-digit format
            return $"{datePart}-{transactionNumber}";
        }
    }
}
